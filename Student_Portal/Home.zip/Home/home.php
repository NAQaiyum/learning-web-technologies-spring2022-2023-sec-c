<!DOCTYPE html>
<html>
<head>
	<title>First Page</title>
</head>
<body>
    <center>
		<h1>Welcome to ABC University Portal</h1>
    </center>
    <br>
    <ul>
	  <center><b><a href="regform.php">Login & Registration</b></a></center>
    </ul>

</body>
</html>



				
			
		



